import express from 'express';
import cors from 'cors';
import { config } from 'dotenv';

// Make sure to import the models file so that the models are registered with the database
import "./models";
import db from "./database";
import { seed } from './models/seed';
import { getPosts, likePost, unlikePost } from './controllers/posts';

config();
const PORT = process.env.PORT || 4321;


async function main() {
    await db.sync({ force: true })
    await seed();


    const app = express();
    app.use(cors());
    app.use(express.json());
    app.get('/api/posts', getPosts);
    app.post('/api/posts/:id/like', likePost);
    app.post('/api/posts/:id/unlike', unlikePost);
    app.use('/public', express.static('public'));

    app.listen(PORT, () => {
        console.log(`Server is running on http://localhost:${PORT}`);
    });
}

main();
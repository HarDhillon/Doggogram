import { Post } from "../models";
import type { Request, Response, NextFunction } from "express";

const baseUrl = "http://localhost:4321/api/posts";

/**
 * Get all posts.
 * 
 * Endpoint: GET /api/posts
 * Query parameters:
 *  - limit: number of posts to return, default 10
 *  - offset: number of posts to skip, default 0
 * 
 * Response:
 *  - 200 OK on success
 *  - 500 Internal Server Error on failure
 * 
 * Body:
 *  - posts: Array of posts
 *  - limit: The limit used in the query
 *  - offset: The offset used in the query
 *  - total: The total number of posts
 *  - next: The next url to use to get more posts, if any
 *  - previous: The previous url to use to get previous posts, if any
 */
export async function getPosts(req: Request, res: Response, next: NextFunction) {
    const limit = req.query.limit ? parseInt(req.query.limit as string) : 10;
    const offset = req.query.offset ? parseInt(req.query.offset as string) : 0;

    try {
        const posts = await Post.findAll({
            limit,
            offset,
            order: [['createdAt', 'DESC']]
        });
        const total = await Post.count();
        const nextUrl = (offset + limit) < total ? baseUrl + `?limit=${limit}&offset=${offset + limit}` : null;
        const previous = (offset - limit) >= 0 ? baseUrl + `?limit=${limit}&offset=${offset - limit}` : null;

        res.json({ posts, limit, offset, total, next: nextUrl, previous });
    } catch (err) {
        next(err);
    }
}

/**
 * Like a post.
 * 
 * Endpoint: POST /api/posts/:id/like
 * Path parameters:
 *  - id: ID of the post to like
 * 
 * Response:
 * - 200 OK on success
 * - 404 Not Found if the post does not exist
 * 
 * Body:
 * - post: The updated post
 */
export async function likePost(req: Request, res: Response, next: NextFunction) {
    const id = req.params.id;

    try {
        const post = await Post.findByPk(id);

        if (!post) {
            res.status(404).json({ message: "Post not found" });
            return;
        }

        post.likes += 1;
        await post.save();

        res.json({ post });
    } catch (err) {
        next(err);
    }
}

/**
 * Unlike a post.
 * 
 * Endpoint: POST /api/posts/:id/unlike
 * Path parameters:
 *  - id: ID of the post to unlike
 * 
 * Response:
 * - 200 OK on success
 * - 404 Not Found if the post does not exist
 * 
 * Body:
 * - post: The updated post
 */
export async function unlikePost(req: Request, res: Response, next: NextFunction) {
    const id = req.params.id;

    try {
        const post = await Post.findByPk(id);

        if (!post) {
            res.status(404).json({ message: "Post not found" });
            return;
        }

        post.likes -= 1;
        await post.save();

        res.json({ post });
    } catch (err) {
        next(err);
    }
}
import { Sequelize } from 'sequelize';

const sequelize = new Sequelize({
  dialect: 'sqlite',
  storage: 'local.db',
  logging: false,
});

process.on('exit', () => {
    sequelize.close();
});

export default sequelize;
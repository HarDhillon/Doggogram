import Post from "./Post";

const baseUrl = "http://localhost:4321/public";

const data = [
    {
        image: `${baseUrl}/flozza_1.jpg`,
        username: "flozza",
        likes: 9999,
        caption: "Hard day at the office 😴",
    },
    {
        image: `${baseUrl}/101_snoozes.jpg`,
        username: "101 Snoozes",
        likes: 58,
        caption: "Another day, another nap 💤",
    },
    {
        image: `${baseUrl}/addies_life.jpg`,
        username: "Addies Life",
        likes: 128,
        caption: "What are you looking at? 🐶",
    },
    {
        image: `${baseUrl}/albert_the_dog.jpg`,
        username: "Albert the dog",
        likes: 89,
        caption: "Can we go outside now?",
    },
    {
        image: `${baseUrl}/cute_but_dangerous.jpg`,
        username: "Cute but dangerous",
        likes: 120,
        caption: "Is that a squirrel? 🐿",
    },
    {
        image: `${baseUrl}/fast_girl.jpg`,
        username: "Fast girl",
        likes: 1100,
        caption: `Here are my top tips for running 🏃‍♀️:
        1. Start running
        2. Keep running
        3. Don't stop running
        Follow me for more inspiration!`,
    },
    {
        image: `${baseUrl}/geoff.jpg`,
        username: "Geoff",
        likes: 100,
        caption: "Can't wait to open my presents 🎁",
    },
    {
        image: `${baseUrl}/gremlin.jpg`,
        username: "Gremlin",
        likes: 100,
        caption: "Can't believe that squirrel got away 🐿",
    },
    {
        image: `${baseUrl}/hound_gang.jpg`,
        username: "Hound Gang",
        likes: 950,
        caption: "This is the cover for our new album 🎵",
    },
    {
        image: `${baseUrl}/janet.jpg`,
        username: "Janet",
        likes: 54,
        caption: "Look at this photograph! #tbt #nickelback",
    },
    {
        image: `${baseUrl}/mr_crazy_butt.jpg`,
        username: "Mr Crazy Butt",
        likes: 43,
        caption: "RUFF RUFF RUFF",
    },
    {
        image: `${baseUrl}/mr_whiskers.jpg`,
        username: "Mr Whiskers",
        likes: 43,
        caption: "I'm not a puppy, I'm a lion! 🦁",
    },
    {
        image: `${baseUrl}/squiggles.jpg`,
        username: "Squiggles",
        likes: 921,
        caption: "I'm a good boy!!",
    },
    {
        image: `${baseUrl}/ruffles.jpg`,
        username: "Ruffles",
        likes: 34,
        caption: "Can I have another one?????",
    },
    {
        image: `${baseUrl}/furrball.jpg`,
        username: "Furrball",
        likes: 342,
        caption: "One more treat please 🍖",
    },
    {
        image: `${baseUrl}/scruffy_bunch.jpg`,
        username: "Scruffy Bunch",
        likes: 884,
        caption: "Off to the park with the gang 🐕",
    },
    {
        image: `${baseUrl}/playful_doggo.jpg`,
        username: "Playful Doggo",
        likes: 365,
        caption: "Don't take life too seriously 🤪",
    },
    {
        image: `${baseUrl}/shya_lebark.jpg`,
        username: "Shya Lebark",
        likes: 43,
        caption: "Can we please go back home??",
    },
    {
        image: `${baseUrl}/posh_pup.jpg`,
        username: "Posh Pup",
        likes: 65,
        caption: "Ready for the weekend in the manor! 🏰",
    },
    {
        image: `${baseUrl}/souldog.jpg`,
        username: "Souldog",
        likes: 4129,
        caption: "Just chilling in the sun ☀️",
    },
]

export async function seed() {
    const ct = await Post.count();
    if (ct > 0) {
        console.log("Data already seeded");
        return;
    }
    console.log("Seeding data");
    return Post.bulkCreate(data);
}
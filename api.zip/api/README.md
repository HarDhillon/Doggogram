# Doggogram API

## Getting started

To get started, please make sure you have a version of node greater than or equal
to 18.20 installed in your machine. This was actually developed using v18.20.2.

Once you have a valid version of node, please install all the dependencies using:

```sh
npm i
```

The only library that could give you some grief would be
[sqlite3](https://www.npmjs.com/package/sqlite3). If you have any issues
with getting that to work, please refer to their documentation.

If all the dependencies installed correctly, then run:

```sh
npm run dev
```

To start the server under watch mode. This will enable you to make any changes and for
it to hot reload if you so desire. Otherwise, using `npm start` is more than sufficient.

## Database migration

For the sake of simplicity, migrations have not been included. Instead, the database is
automatically sync'ed with all changes to the models. Therefore, there is no further
steps necessary to get the API to work.

Bear in mind, however, that if you make significant changes to the database layer,
the data seeds may not work anymore, therefore, if you make any changes to existing
tables, make sure they are backwards compatible.

## Understanding the code

This API is very simple on purpose. It is composed of a simple database layer, a controller
layer and an entrypoint. All of these parts can be found within the `src` directory.

The database layer can be found within the `models` directory and contains the definitions
of the database tables.

The controller layer can be found within the `controllers` directory and is responsible for
handling request/response cycles. Endpoint documentation can be found within this directory.
There is no OpenAPI documentation, you will need to inspect the code and responses you get
from the API.

The entrypoint of the application is the file `main.ts`.